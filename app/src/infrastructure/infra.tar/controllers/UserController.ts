// src/controllers/UserController.ts
import UserRepository from '@src/infrastructure/repositories/UserRepository';
import { BaseRequest, BaseResponse } from '@src/infrastructure/servers/base';
import { AccountLockedError, AuthenticationError, FoundError, NotFoundError } from '@src/shared/Errors';
import { UserService } from '@src/application/services/UserService';
import { LoginService } from '@src/application/services/LoginService';

class UserController {
    private static userRepository = new UserRepository();
    private static userService = new UserService(this.userRepository);
    private static loginService = new LoginService(this.userRepository);

    static async login(req: BaseRequest, res: BaseResponse) {
        console.log(req.clientIp);
        try {
            const token = await this.loginService.login(req.body.username, req.body.password, req.clientIp!);
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Authorization', "Bearer " + token);
            res.json({ message: "Login successful" });
        }
        catch (error) {
            this.handleError(error as Error, res);
        }   
    }

    static async getUser(req: BaseRequest, res: BaseResponse) {
        try {
            const result = await this.userService.getUser(parseInt(req.query.id));
            res.json(result);
        }
        catch (error) {
            this.handleError(error as Error, res);
        }
    }

    static async getUsers(req: BaseRequest, res: BaseResponse) {
        try {
            const result = await this.userService.getUsers();
            res.json(result);
        }
        catch (error) {
            this.handleError(error as Error, res);
        }
    }

    static async createUser(req: BaseRequest, res: BaseResponse) {
        //console.log("==> ", req.body, "@UserController.createUser()");
        try {
            const result = await this.userService.createUser({
               username: req.body.username,
                password: req.body.password,
                email: req.body.email,
                fullname: req.body.fullname,
                level: req.body.level
            });
            res.status(201).json(result);
        }
        catch (error) {
            this.handleError(error as Error, res);
        }
    }

    static async updateUser(req: BaseRequest, res: BaseResponse) {
        //console.log("==> ", req.body, "@UserController.updateUser()");
        try {
            const result = await this.userService.updateUser({
                id: req.body.id,
                username: req.body.username || undefined,
                password: req.body.password || undefined,
                email: req.body.email || undefined,
                fullname: req.body.fullname || undefined,
                level: req.body.level || undefined
            });
            res.json(result);
        }
        catch (error) {
            this.handleError(error as Error, res);
        }
    }

    private static handleError(error: Error, response: BaseResponse) {
        console.log("UserController.handleError()");
        console.error(error);

        if (error instanceof NotFoundError)
            return response.status(404).json({ error: error.message });
        
        if (error instanceof FoundError)
            return response.status(409).json({ error: error.message });

        if (error instanceof AuthenticationError)
            return response.status(401).json({ error: error.message });

        if (error instanceof AccountLockedError)
            return response.status(403).json({ error: error.message });
        
        return response.status(500).json({ error: 'Internal server error' });
    }
}

export default UserController;

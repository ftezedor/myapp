// expressServer.ts
import express, { Request, Response } from 'express';
import http from 'http';
import https from 'https';
import { BaseServer, BaseServerOptions } from '@src/infrastructure/servers/base';
import { ExpressRequest, ExpressResponse } from '@src/infrastructure/servers/express';
import fs from 'fs';

const bodyParser = require('body-parser');

export default class ExpressServer extends BaseServer {
    private app: express.Application;

    constructor(options?: BaseServerOptions) {
        super(options);
        this.app = express();
        this.app.use(bodyParser.json());
    }

    // Overriden from WebServer
    async start(): Promise<this> {
        /*
        if (this.protocol === 'https') {
            // Perform type assertion to check if this.serverOptions matches the ServerOptions type
            if (!(typeof this.serverOptions === 'object' && this.serverOptions !== null)) {
                throw new Error('serverOptions must be an object');
            }
        
            // Check if serverOptions is empty
            if (Object.keys(this.serverOptions).length === 0) {
                throw new Error('serverOptions is required');
            }
        }
        */
        
        const server = this.protocol === 'http'
            ? http.createServer(this.app) 
            : https.createServer({
                key: fs.readFileSync(this.httpsCertificateKey!),
                cert: fs.readFileSync(this.httpsCertificate!)
            }, this.app);

        return new Promise((resolve, reject) => {
            server.listen(this.port, this.host, () => {
                console.log(`Express server is running on ${this.protocol}://${this.host}:${this.port}`);
                resolve(this);
            }).on('error', (err: any) => {
                reject(err);
            });
        });
    }

    // Overriden from WebServer
    route(method: string, path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        console.log(`Defining route ${method} ${path}`);
        
        if (method.toLowerCase() === 'all')
            return this.all(path, handler);
        
        if (method.toLowerCase() === 'get') 
            return this.get(path, handler);
                
        if (method.toLowerCase() === 'post')
            return this.post(path, handler);

        if (method.toLowerCase() === 'put') 
            return this.put(path, handler);
        
        if (method.toLowerCase() === 'delete')
            return this.delete(path, handler);

        throw new Error(`Method ${method} is not allowed.`);
    }

    private all(path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        this.app.all(path, (req: Request, res: Response) => handler(new ExpressRequest(req), new ExpressResponse(res)));
    }

    private get(path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        this.app.get(path, (req: Request, res: Response) => handler(new ExpressRequest(req), new ExpressResponse(res)));
    }

    private post(path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        this.app.post(path, (req: Request, res: Response) => handler(new ExpressRequest(req), new ExpressResponse(res)));
    }

    private put(path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        this.app.put(path, (req: Request, res: Response) => handler(new ExpressRequest(req), new ExpressResponse(res)));
    }

    private delete(path: string, handler: (req: ExpressRequest, res: ExpressResponse) => void): void {
        this.app.delete(path, (req: Request, res: Response) => handler(new ExpressRequest(req), new ExpressResponse(res)));
    }
}


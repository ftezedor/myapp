import Fastify, { FastifyInstance, FastifyRequest as Request, FastifyReply as Response } from 'fastify';
import { BaseServer, BaseServerOptions } from '@src/infrastructure/servers/base';
import { FastifyRequest } from './FastifyRequest';
import { FastifyResponse } from './FastifyResponse';
import fs from 'fs';

//import { Server as HttpServer } from 'http';
//import { Server as HttpsServer, ServerOptions } from 'https';

export class FastifyServer extends BaseServer {
    private app: FastifyInstance;

    constructor(options?: BaseServerOptions) {
        super(options);
        if (this.protocol === 'https') {
            this.app = Fastify({
                https: {
                    key: fs.readFileSync(this.httpsCertificateKey!),
                    cert: fs.readFileSync(this.httpsCertificate!)
                }
            });
        } else {
            this.app = Fastify()
        }
    }

    async start(): Promise<this> {
        /*
        if (this.protocol === 'https') {
            if (!(typeof this._serverOptions === 'object' && this._serverOptions !== null)) {
                throw new Error('serverOptions must be an object');
            }
        
            if (Object.keys(this._serverOptions).length === 0) {
                throw new Error('serverOptions is required');
            }
        }
        */

        /*
        if (this.protocol === 'https') {
            this.app.register(require('fastify-https'), {
                key: this.serverOptions.key,
                cert: this.serverOptions.cert});
        }
        */

        return new Promise((resolve, reject) => {
            this.app.listen({
                host: this.host,
                port: this.port
            }).then(() => {
                console.log(`Fastify server is running on ${this.protocol}://${this.host}:${this.port}`);
                resolve(this);
            }).catch((err: Error) => {
                reject(err);
            })
        });
    }

    // Overriden from WebServer
    //public route(method: string, path: string, handler: (req: BaseRequest, res: BaseResponse) => any): any;
    public route(method: string, path: string, handler: (req: FastifyRequest, res: FastifyResponse) => any): any {
        console.log(`Defining route ${method} ${path}`);
        
        if (method.toLowerCase() === 'all')
            return this.all(path, handler);
        
        if (method.toLowerCase() === 'get') 
            return this.get(path, handler);
                
        if (method.toLowerCase() === 'post')
            return this.post(path, handler);

        if (method.toLowerCase() === 'put') 
            return this.put(path, handler);
        
        if (method.toLowerCase() === 'delete')
            return this.delete(path, handler);

        throw new Error(`Method ${method} is not allowed.`);
    }

    private all(path: string, handler: (req: FastifyRequest, res: FastifyResponse) => void): void {
        this.app.all(path, async (req: Request, res: Response) => handler(new FastifyRequest(req), new FastifyResponse(res)));
    }

    private get(path: string, handler: (req: FastifyRequest, res: FastifyResponse) => void): void {
        this.app.get(path, async (req: Request, res: Response) => handler(new FastifyRequest(req), new FastifyResponse(res)));
    }

    private post(path: string, handler: (req: FastifyRequest, res: FastifyResponse) => void): void {
        this.app.route({
            method: 'POST',
            url: path,
            handler: async (req: Request, res: Response) => handler(new FastifyRequest(req), new FastifyResponse(res))
        });
    }

    private put(path: string, handler: (req: FastifyRequest, res: FastifyResponse) => void): void {
        this.app.route({
            method: 'PUT',
            url: path,
            handler: async (req: Request, res: Response) => handler(new FastifyRequest(req), new FastifyResponse(res))
        });
    }

    private delete(path: string, handler: (req: FastifyRequest, res: FastifyResponse) => void): void {
        this.app.route({
            method: 'DELETE',
            url: path,
            handler: async (req: Request, res: Response) => handler(new FastifyRequest(req), new FastifyResponse(res))
        });
    }
}

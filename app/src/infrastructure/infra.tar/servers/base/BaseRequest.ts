export default interface BaseRequest {
    get method(): string;
    get url(): string;
    //getHeader(name: string): string | undefined;
    get headers(): { [key: string]: string }
    get path(): string;
    /**
     * get values from query string
     */
    get query(): { [key: string]: string };
    get body(): any;
    get clientIp(): string | undefined; // TODO: remove clientip
}

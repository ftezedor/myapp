import { BaseRepository } from "./BaseRepository";
import { UserEntity } from "@src/domain/entities/UserEntity";
import BaseEntity from "@src/domain/entities/BaseEntity";

export default class ProductRepository implements BaseRepository<BaseEntity> {
    private products = [{
        id: 1,
        name: 'Product 1',
        price: 100
    }, {
        id: 2,
        name: 'Product 2',
        price: 200
    }, {
        id: 3,
        name: 'Product 3',
        price: 300
    }, {
        id: 4,
        name: 'Product 4',
        price: 400
    }, {
        id: 5,
        name: 'Product 5',
        price: 500
    }];

    create(entity: BaseEntity): Promise<BaseEntity> {
        throw new Error("Method not implemented.");
    }

    update(updates: Partial<BaseEntity>): Promise<BaseEntity | null> {
        throw new Error("Method not implemented.");
    }

    findById(id: string): Promise<BaseEntity | null> {
        const prod = this.products.find(prod => id === id);
        return Promise.resolve(prod! as BaseEntity);
    }

    findAll(): Promise<BaseEntity[]> {
        return Promise.resolve(this.products as BaseEntity[]);
    }

    deleteById(id: string): Promise<boolean> {
        throw new Error("Method not implemented.");
    }

    count(query?: any): Promise<number> {
        throw new Error("Method not implemented.");
    }

    query(query: any): Promise<BaseEntity[]> {
        throw new Error("Method not implemented.");
    }
}
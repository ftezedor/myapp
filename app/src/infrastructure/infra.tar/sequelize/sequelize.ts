import { Sequelize, DataTypes } from 'sequelize';

export const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: '/tmp/lab.db',
    logging: false
});

/*
export new Sequelize({
    dialect: 'sqlite',
    storage: './.data/database.sqlite',
});

module.exports = sequelize;

*/
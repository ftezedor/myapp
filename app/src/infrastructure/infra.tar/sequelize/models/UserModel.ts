/*
 * models/users.js
 */
import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from '../sequelize';
import { Secure } from '../../../shared/utils/security';

interface UserAttributes {
    id: number;
    username: string;
    email: string;
    password: string;
    salt: string;
    fullname: string;
    level: string;
    retries: number;
    lockUntil: Date;
    // Add other fields as necessary
  }
  
interface UserCreationAttributes extends Optional<UserAttributes, 'id' | 'lockUntil'> {}

export class UserModel extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
    id!: number;
    username!: string;
    email!: string;
    password!: string;
    salt!: string;
    fullname!: string;
    level!: string;
    retries!: number;
    lockUntil!: Date;
}
 
UserModel.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    username: {
        type: DataTypes.STRING,
        unique: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    salt: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fullname: {
        type: DataTypes.STRING,
        allowNull: false
    },
    level: {
        type: DataTypes.ENUM('admin', 'regular', 'readonly'),
        allowNull: false
    },
    retries: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    lockUntil: {
        type: DataTypes.DATE,
        allowNull: true
    }
},
{
    sequelize: sequelize, 
    modelName: 'users',
    timestamps: false
});

(async () => {
    try 
    {
        await sequelize.sync({ force: false });

        // Check if admin user exists
        const [user, created] = await UserModel.findOrCreate({
            where: { username: 'admin' },
            defaults: {
                username: 'admin',
                email: 'admin@example.com',
                password: await Secure.Password.hash('changeme', '985256126889126f'),
                salt: '985256126889126f',
                fullname: 'Admin User',
                level: 'admin',
                retries: 3 // 3 failed login attempts
            }
        });
    } 
    catch (error) 
    {
        console.error("Error synchronizing models:", error);
    }
})();
